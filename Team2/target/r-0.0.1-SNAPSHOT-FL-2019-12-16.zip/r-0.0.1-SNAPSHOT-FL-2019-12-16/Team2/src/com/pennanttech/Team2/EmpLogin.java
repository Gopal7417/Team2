package com.pennanttech.Team2;

public class EmpLogin {
 
  private String Email_Id;
  


public String getEmail_Id() {
	return Email_Id;
}
public void setEmail_Id(String email_Id) {
	Email_Id = email_Id;
}
private String Password;



public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}

}
