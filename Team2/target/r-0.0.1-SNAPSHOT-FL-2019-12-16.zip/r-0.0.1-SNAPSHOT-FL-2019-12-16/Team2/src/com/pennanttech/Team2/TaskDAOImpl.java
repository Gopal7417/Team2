package com.pennanttech.Team2;

import java.util.List;
import java.sql.*;
import javax.sql.*;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;

public class TaskDAOImpl implements TaskDAO {
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcTemplate jdbcTemplate;
	protected DataFieldMaxValueIncrementer taskIncer;
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setJdbcTemplate(JdbcTemplate  jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setTaskIncer(DataFieldMaxValueIncrementer taskIncer) {
		this.taskIncer = taskIncer;
	}

	public Task insert(Task t) throws Exception {
	
		
		String sql = "INSERT INTO tasks VALUES(?, ?)";
		Object[] params = new Object[] {  t.getTitle(), t.getDescription() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR};
		jdbcTemplate.update(sql, params,types);
		
		return t;
	}

	public Task update(Task t) throws Exception {
		String sql = "UPDATE tasks SET title = ?, description = ? WHERE id = ?";
		Object[] params = new Object[] { t.getTitle(), t.getDescription(), t.getId() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.INTEGER};
		jdbcTemplate.update(sql, params, types);
		
		return t;
	}

	public void delete(Task t) throws Exception {
		String sql = "DELETE FROM tasks WHERE id = ?";
		Object[] params = new Object[] { t.getId() };
		int types[] = new int[] { Types.INTEGER};
		jdbcTemplate.update(sql, params, types);
	}

	protected class TaskMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	model m = new model();
			m.setJob_Title(rs.getString(8));
			return m;
		}
		
		
		
		
	}
	public Task findById(int id) throws Exception {
		String sql = "SELECT * FROM tasks WHERE id = ?";
		Object[] params = new Object[] { id };
		int types[] = new int[] { Types.INTEGER};
		
		List ts = jdbcTemplate.query(sql, params, types, new TaskMapper());
		if (ts.isEmpty())
			return null;
		return (Task)ts.get(0); 
	}

	public List findAll() throws Exception {
		String sql = "SELECT * FROM job ";
		return jdbcTemplate.query(sql, new TaskMapper());
	}
	
	protected class LocMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	    LocationModel lm = new LocationModel();	    
	    lm.setLocId(rs.getString(1));
	    lm.setLocation(rs.getString(2));
		return lm;
		}}
	
	public List Locations() throws Exception{		
		String sql = "SELECT * FROM Location";
		return jdbcTemplate.query(sql, new LocMapper());
		
		
	}

	
}
