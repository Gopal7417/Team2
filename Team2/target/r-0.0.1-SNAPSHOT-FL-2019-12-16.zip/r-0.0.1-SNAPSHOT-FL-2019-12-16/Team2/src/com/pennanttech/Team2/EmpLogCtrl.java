package com.pennanttech.Team2;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

public class EmpLogCtrl extends Window {
 public void popup() {
	 Window window = (Window)Executions.createComponents("popup.zul", null, null);
	 window.doModal();
	       
	    }
FormDAO db1;
		
		Component click;
		 public void verifyLogin() {
			ApplicationContext ctx = 
					WebApplicationContextUtils.getRequiredWebApplicationContext(
						(ServletContext)getDesktop().getWebApp().getNativeContext());
			db1=(FormDAO)ctx.getBean("taskDAO");			
			System.out.println("enter");
			Textbox b=(Textbox)this.getFellow("Email_Id");
			String b1=b.getValue();
			Textbox c=(Textbox)this.getFellow("Password");
			String c1=c.getValue();
			EmpLogin e=new EmpLogin();
			e.setEmail_Id(b1);
			db1.login(e);
			
			 Executions.sendRedirect("Search.zul");
			
		/*	try {
				EmpLogin e=new EmpLogin();
			    e.setEmail_Id(b1);
				e.setPassword(c1);

				int val=db1.login(e);
				
				}
				catch(Exception et)
				{
					System.out.println(et);
				}*/
 }
		public char[] getEmail_Id() {
			// TODO Auto-generated method stub
			return null;
		}
 }
	
	


