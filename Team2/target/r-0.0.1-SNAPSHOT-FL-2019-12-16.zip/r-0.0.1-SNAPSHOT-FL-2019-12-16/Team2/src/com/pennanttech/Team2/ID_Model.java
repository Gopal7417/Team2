package com.pennanttech.Team2;

public class ID_Model {
	private ID_Model id = null;
	private int Index;
	public int getIndex() {
		return Index;
	}

	public void setIndex(int index) {
		System.out.println(index);
		this.Index = index;
	}

	public ID_Model getId() {
		return id;
	}

	public void setId(ID_Model id) {
		this.id = id;
	}
	}
