package com.pennanttech.Team2;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Stream;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.zkoss.zk.ui.Executions;


import com.pennanttech.Team2.Empr.Job_Tbl;

public class Impl implements FormDAO {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcTemplate jdbcTemplate;
	protected DataFieldMaxValueIncrementer taskIncer;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setTaskIncer(DataFieldMaxValueIncrementer taskIncer) {
		this.taskIncer = taskIncer;
	}
	/*
	 * protected class LoginMapper implements RowMapper { public Object
	 * mapRow(ResultSet rs, int rowNum) throws SQLException {
	 * 
	 * loginmodel lm = new loginmodel(); lm.setPassword(rs.getString("password"));
	 * 
	 * return rowNum; }
	 */
	  public int validuser(Jobmodel m) {
		// TODO Auto-generated method stub
		
		String a = m.getJob_Title();
		int b = m.getSalary();
		int c = m.getNo_of_Openings();
		String d = m.getJob_Location();
		String e = m.getMinimum_Qualification();
		int f = m.getExperince();
		String g = m.getJob_Role();
		System.out.println(g);
		String h = m.getJob_Description();
		String i =m.getCompany_Name();
		String j =m.getRecruiter_Name();
		long k = m.getPhone_Number();
		String l =m.getEmail_Id();
		String n = m.getJob_Address();
		String sql = "insert into job values(NEXT VALUE FOR empr_id,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] params = new Object[] { a, b, c, d, e, f, g, h, i,j, k, l, n };
		int types[] = new int[] {Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR,
				Types.VARCHAR };
		jdbcTemplate.update(sql, params, types);
		//Executions.sendRedirect("");
		return 0;
	}

	public int users(Experiencemodel f) {
		// TODO Auto-generated method stub
		
		String z = f.getName();
		String y = f.getEmail_Id();
		String x = f.getCreate_Password();
		long w = f.getMobile_Number();
		String v = f.getGender();
		String u  = f.getHighest_Qualification();
		String t = f.getCourse();
		String s = f.getSpecialization();
		String r =f.getUniversity();
		int q=f.getPassing_Year();
		String p= f.getSkills();
		String o=f.getCompany_Name();
		int p1=f.getNo_of_Years();
		String p2=f.getJob_Role();
		String sql = "insert into emp( emp_id,Name,Email_Id,Create_Password,Mobile_Number,Gender,Highest_Qualification,Course,Specialization,University,Passing_Year,Skills,Company_Name,No_of_Years,Job_Role) values(NEXT VALUE FOR emp_id,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] params = new Object[] {z,y,x,w,v,u,t,s,r,q,p,o,p1,p2 };
		int types[] = new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.NUMERIC, Types.VARCHAR,
				Types.VARCHAR,Types.INTEGER,Types.VARCHAR};
		jdbcTemplate.update(sql, params, types);
		//Executions.sendRedirect("");
		return 0;
	}		     
		public int validuser(Freshermodel f) {
			// TODO Auto-generated method stub			
			String z = f.getName();
			String y = f.getEmail_Id();
			String x = f.getCreate_Password();
			long w = f.getMobile_Number();
			String v = f.getGender();
			String u  = f.getHighest_Qualification();
			String t = f.getCourse();
			String s = f.getSpecialization();
			String r =f.getUniversity();
			int q=f.getPassing_Year();
			String p= f.getSkills();
			String sql = "insert into emp( emp_id,Name,Email_Id,Create_Password,Mobile_Number,Gender,Highest_Qualification,Course,Specialization,University,Passing_Year,Skills) values(NEXT VALUE FOR emp_id,?,?,?,?,?,?,?,?,?,?,?)";
			Object[] params = new Object[] {z,y,x,w,v,u,t,s,r,q,p, };
			int types[] = new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.NUMERIC, Types.VARCHAR
					};
			jdbcTemplate.update(sql, params, types);
			//Executions.sendRedirect("");
			return 0;
	
	}
		
		public int login(EmpLogin e) {
				
				//get the password for the given user
				String qry = "select password from "
						+ "emp where Email_Id=?";
				System.out.println(e.getEmail_Id());
				try {
				String pwd = (String)jdbcTemplate.queryForObject(qry,new Object[]{e.getEmail_Id()}, String.class );
				
				//verify the password
				if (pwd != null) {
					if (e.getPassword().equals(pwd)) {
						return 0;	//success
					}else {
						return 1;	//wrong password  
					}
				}else {
					return 2;
				}
				
				}catch(Exception ex) {
					return 2;	//user itself wrong
				}
				
			}

		 
		 public int log(emprmodel e1) {
				// TODO Auto-generated method stub
				
				
				String qry = "select password from "
						+ "empr where Email_Id=?";
				System.out.println(e1.getEmail_Id());
				try {
				String pwd = (String)jdbcTemplate.queryForObject(qry,new Object[]{e1.getEmail_Id()}, String.class );
				
				//verify the password
				if (pwd != null) {
					if (e1.getPassword().equals(pwd)) {
						return 0;	//success
					}else {
						return 1;	//wrong password  
					}
				}else {
					return 2;
				}
				
				}catch(Exception ex) {
					return 2;	//user itself wrong
				}
				
			}

		 
		 public int valid(Job_Tbl j) {
				// TODO Auto-generated method stub
				System.out.println("1");
				String j71=j.getJob_Role();
				String j72=j.getJob_Description();
				int j73=j.getSalary();
				int j74=j.getExperience();	
				int j75=j.getNo_of_Openings();				
				String j76=j.getMinimum_Qualification();		
				System.out.println("12");
				Date j77=j.getLast_Date();
			
				 String j78=j.getJob_Location(); 
				 String j79=j.getAddress(); 
				 String j80=j.getSkills();
				 String sql=" insert into Job_tbl(Company_Id,Job_Id,Job_Role,Job_Description,Salary,Experience,No_of_Openings,Minimum_Qualification,last_Date,Job_Location,Address,Skills) values(7,NEXT VALUE FOR Job_Id,?,?,?,?,?,?,?,?,?,?)"; 
				 Object[] params = new Object[] {j71,j72,j73,j74,j75,j76,j77,j78,j79,j80 };
				  int types[] = new int[] {Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
				  Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				  Types.VARCHAR, Types.VARCHAR }; 
				  jdbcTemplate.update(sql, params, types);
				 
				
				return 0;
			}
		 
		 
		 public int cmp(Company_Tbl c) {
				// TODO Auto-generated method stub
				String c1=c.getCompany_Name();
				String c2=c.getRecruiter_Name();
				String c3=c.getEmail_Id();
				String c4=c.getPassword();
				long c5=c.getPhone_number();
				String c6=c.getCurrent_Designation();
				String sql="insert into Company_tbl(Company_Id,Company_Name,Recruiter_Name,Email_Id,Password,Phone_Number,Current_Designation) values(NEXT VALUE FOR Company_Id,?,?,?,?,?,?)";
				 Object[] params = new Object[] {c1,c2,c3,c4,c5,c6};
				 int types[] = new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
						  Types.VARCHAR, Types.BIGINT,Types.VARCHAR }; 
				 jdbcTemplate.update(sql, params, types);
				
				 
				return 0;
			}
			
			
		
		protected class TaskMapper implements RowMapper {
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		model m = new model();
			m.setJob_id(rs.getInt(5));
	        m.setCompany_Name(rs.getString(2));
	       m.setJob_Role(rs.getString(1));
	       m.setJob_Location(rs.getString(3));
	       m.setSalary(rs.getInt(4));
	       return m;
			}
	}			
	public List JobSearch(String Role, String Location) {
	String sql = "select Job_Role,Company_Name,Job_Location,salary,empr_id from job where job_Location = 'vizag' and Job_Role = 'developer'";
      return jdbcTemplate.query(sql, new TaskMapper());
}
	
	protected class JobDataMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			model m = new model();
			m.setJob_Description(rs.getString(1));
			m.setExperince(rs.getInt(2));
			m.setCompany_Name(rs.getString(3));			
			m.setJob_Location(rs.getString(4));
			    
			return m;
		}}
	
	public List Job_Data(int jobid) {
		System.out.println(jobid);
	String sql = "select Job_Description,Experince,Company_Name,Job_Location from job where empr_id =67";			
	return jdbcTemplate.query(sql, new JobDataMapper());
	}



	public List profile(int profileid) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	

}

