package com.pennanttech.Team2;

import java.util.List;

import com.pennanttech.Team2.Empr.Job_Tbl;

public interface FormDAO {
	public int validuser(Jobmodel m);
	public int users(Experiencemodel m1);
	public int validuser(Freshermodel f1);
	public List JobSearch(String Role, String Location) ;
	public List Job_Data(int jobid);
	public int login(EmpLogin e);
	public int log(emprmodel e1);
	public int valid(Job_Tbl j);
	public int cmp(Company_Tbl c);
	public List profile(int profileid);
}
