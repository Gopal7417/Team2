package com.pennanttech.Team2.Empr;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;

import com.pennanttech.Team2.Empr.*;;


public class EmprDAOImpl implements EmprDAO{
	private static Logger logger = Logger.getLogger(EmprHome_Ctrl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcTemplate jdbcTemplate;
	protected DataFieldMaxValueIncrementer taskIncer;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setTaskIncer(DataFieldMaxValueIncrementer taskIncer) {
		this.taskIncer = taskIncer;
	}
	
	protected class EmprJob_DataMap implements RowMapper {
		
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		Job_Tbl jb = new Job_Tbl();
			jb.setJob_Role(rs.getString(1));
			jb.setLast_Date(rs.getDate(2));
			jb.setRegister_Date(rs.getDate(3));
			jb.setJob_Location(rs.getString(4));
			jb.setJob_Id(rs.getInt(5));
			return jb;
		}
		}	
	public List EmprJob_Data(int jobid) {		
	logger.info("enter");		
	String  sql="select Job_Role , last_Date ,Register_Date ,Job_Location,job_id from Job_tbl where Company_Id = 7" ;		
	return jdbcTemplate.query(sql, new EmprJob_DataMap());
	}
	

}
