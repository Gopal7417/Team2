package com.pennanttech.Team2.Empr;

import java.util.List;

public interface EmprDAO {
	
	public List EmprJob_Data(int jobid);

}
