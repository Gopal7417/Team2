package com.pennanttech.Team2;

import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.zkoss.zk.ui.Component;
import org.zkoss.zul.Div;
import org.zkoss.zul.Intbox;
import org.zkoss.zul.Longbox;
import org.zkoss.zul.Radiogroup;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;


public class FresherCtrl extends Div{
	
	FormDAO db1;
	
	private Component click;
	public void verifyFresher() {
		System.out.println("enter");
		ApplicationContext ctx = 
				WebApplicationContextUtils.getRequiredWebApplicationContext(
					(ServletContext)getDesktop().getWebApp().getNativeContext());
		db1=(FormDAO)ctx.getBean("taskDAO");
		
	
	Textbox b=(Textbox)this.getFellow("Name");
	String b1=b.getValue();
	Textbox c=(Textbox)this.getFellow("Email_Id");
	String c1=c.getValue();
	Textbox d=(Textbox)this.getFellow("Create_Password");
	String d1=d.getValue();
	Longbox e=(Longbox)this.getFellow("Mobile_Number");
	long e1=e.getValue();
	Radiogroup f=(Radiogroup)this.getFellow("Gender");
	String f2=f.getName();
	Textbox g=(Textbox)this.getFellow("Highest_Qualification");
	String g1=g.getValue();
	Textbox h=(Textbox)this.getFellow("Course");
	String h1=h.getValue();
	Textbox i=(Textbox)this.getFellow("Specialization");
	String i1=i.getValue();
	Textbox j=(Textbox)this.getFellow("University");
	String j1=j.getValue();
	Intbox k=(Intbox)this.getFellow("Passing_Year");
	int k1=k.getValue();
	Textbox l=(Textbox)this.getFellow("Skills");
	String l1=l.getValue();
	
		/*
		 * Textbox p3=(Textbox)this.getFellow("Resume"); String n6=p3.getValue();
		 */
try
	{
		Freshermodel f1=new Freshermodel();
      
		f1.setName(b1);
		f1.setEmail_Id(c1);
		f1.setCreate_Password(d1);
		f1.setMobile_Number(e1);
		f1.setGender(f2);
		f1.setHighest_Qualification(g1);
		f1.setCourse(h1);
		f1.setSpecialization(i1);
		f1.setUniversity(j1);
		f1.setPassing_Year(k1);
		f1.setSkills(l1);
		
	
	int val=db1.validuser(f1);
	}
	catch(Exception et)
	{
		System.out.println(et);
	}

}
}




