package com.pennanttech.Team2;

public class model {
  private int Job_id;
  private String Job_Title;
  private int Salary;
  private int No_of_Openings;
  private String Job_Location;
  private String Minimum_Qualification;
  private int Experince;
  private String Job_Role;
  private String Job_Description;
  private String Company_Name;
  private String Recruiter_Name;
  private long Phone_Number;
  private String Email_Id;
  private String Job_Address;

  public String getJob_Title() {
	return Job_Title;
}
public void setJob_Title(String job_Title) {
	Job_Title = job_Title;
}
public int getSalary() {
	return Salary;
}
public void setSalary(int salary) {
	Salary = salary;
}
public int getNo_of_Openings() {
	return No_of_Openings;
}
public void setNo_of_Openings(int no_of_Openings) {
	No_of_Openings = no_of_Openings;
}
public String getJob_Location() {
	return Job_Location;
}
public void setJob_Location(String job_Location) {
	Job_Location = job_Location;
}
public String getMinimum_Qualification() {
	return Minimum_Qualification;
}
public void setMinimum_Qualification(String minimum_Qualification) {
	Minimum_Qualification = minimum_Qualification;
}
public int getExperince() {
	return Experince;
}
public void setExperince(int experince) {
	Experince = experince;
}

public String getJob_Role() {
	return Job_Role;
}
public void setJob_Role(String job_Role) {
	Job_Role = job_Role;
}
public String getJob_Description() {
	return Job_Description;
}
public void setJob_Description(String job_Description) {
	Job_Description = job_Description;
}
public String getCompany_Name() {
	return Company_Name;
}
public void setCompany_Name(String company_Name) {
	Company_Name = company_Name;
}
public String getRecruiter_Name() {
	return Recruiter_Name;
}
public void setRecruiter_Name(String Recruiter_Name) {
	this.Recruiter_Name = Recruiter_Name;
}
public long getPhone_Number() {
	return Phone_Number;
}
public void setPhone_Number(long phone_Number) {
	Phone_Number = phone_Number;
}
public String getEmail_Id() {
	return Email_Id;
}
public void setEmail_Id(String email_Id) {
	Email_Id = email_Id;
}
public String getJob_Address() {
	return Job_Address;
}
public void setJob_Address(String job_Address) {
	Job_Address = job_Address;
}
public int getJob_id() {
	return Job_id;
}
public void setJob_id(int job_id) {
	Job_id = job_id;
}



  
}
